package com.qa.TestBase;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import com.qa.PageLayer.CurrentWeatherPage;
import com.qa.PageLayer.DailyWeatherForecastPage;
import com.qa.PageLayer.DashboardPage;
//import com.qa.Utility.UtilClass;
import com.qa.PageLayer.WeatherForecastPage;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBase {
	public static WebDriver driver;
	public DashboardPage dash;
	public WeatherForecastPage weather;
	public CurrentWeatherPage cweather;
	public DailyWeatherForecastPage dweather;

	@Parameters("browser")
	@BeforeMethod
	public void setup() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://www.accuweather.com");
		driver.manage().window().maximize();

		driver.manage().deleteAllCookies();
		driver.findElement(By.xpath("//div[@class='banner-button policy-accept']")).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		// driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		dash = new DashboardPage();
		weather = new WeatherForecastPage();
		cweather = new CurrentWeatherPage();
		dweather = new DailyWeatherForecastPage();

		// ut=new UtilClass();

	}

	@AfterMethod
	public void tearDown() {
		// driver.quit();
	}

}
