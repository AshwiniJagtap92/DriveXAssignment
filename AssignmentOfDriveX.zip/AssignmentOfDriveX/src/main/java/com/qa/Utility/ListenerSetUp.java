package com.qa.Utility;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;



public class ListenerSetUp implements ITestListener 
{

	@Override
	public void onTestStart(ITestResult result) {
		System.out.println("Test Execution Started");
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println("Test Execution Completed");
	}

	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println("Test Execution failed");
		UtilClass.screens(result.getName()+System.currentTimeMillis());
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		System.out.println("Test Execution Skipped");
	}

	

}
