package com.qa.PageLayer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.TestBase.TestBase;

public class WeatherForecastPage extends TestBase {
	public WeatherForecastPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = ("//a[@class='cur-con-weather-card card-module  content-module lbar-panel']"))
	private WebElement More_Details;

	public void Click_On_MoreDetails() {
		More_Details.click();
	}

}
