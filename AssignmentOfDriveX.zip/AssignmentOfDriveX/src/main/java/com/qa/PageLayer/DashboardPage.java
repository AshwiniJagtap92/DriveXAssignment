package com.qa.PageLayer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.TestBase.TestBase;

public class DashboardPage extends TestBase {
	public DashboardPage() {
		PageFactory.initElements(driver, this);

	}

	@FindBy(xpath = "//input[@name='query']")
	private WebElement Search_box;

	public void enterSearchBox(String Location) {
		Search_box.sendKeys(Location);
	}

	
	@FindBy(xpath = "//div[text()='Pune, Maharashtra, IN']")
	private WebElement clickOnLocationName;

	public void clickOnLocationName() {
		clickOnLocationName.click();
	}

}
