package com.qa.PageLayer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.TestBase.TestBase;

public class CurrentWeatherPage extends TestBase {
	public CurrentWeatherPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = ("//a[@href='/en/in/pune/204848/daily-weather-forecast/204848?day=2']"))
	private WebElement Rightwards_Arrow;

	public void Click_On_RightwardsArrow() {
		Rightwards_Arrow.click();
	}

}
