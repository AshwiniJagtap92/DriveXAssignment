package com.qa.PageLayer;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.TestBase.TestBase;

import io.opentelemetry.exporter.logging.SystemOutLogExporter;

public class DailyWeatherForecastPage extends TestBase
{
	public DailyWeatherForecastPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	
	
	
	public void sample()
	{
		System.out.println(driver.findElement(By.xpath("//div[@class='temperature']")).getText());
		
		for(int i=1;i<=10;i++)
		{
			
			String a=driver.findElement(By.xpath("(//p[@class='panel-item'])["+i+"]")).getText();
			//String b=driver.findElement(By.xpath("(//span[@class='value'])["+i+"]")).getText();
			System.out.println(a);
			
			//System.out.print(" :: "+b);
			
			
		}
		
		
	}
	
	
	
	
	
	

}
