package com.qa.TestLayer;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.github.dockerjava.transport.DockerHttpClient.Response;
import com.qa.TestBase.TestBase;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.specification.RequestSpecification;

public class DashboardTest extends TestBase {
	@Test
	public void VerifyDashTest() throws InterruptedException {

		dash.enterSearchBox("pune");
		Thread.sleep(2000);
		dash.clickOnLocationName();
		Thread.sleep(2000);
		// ut.util(0,800);
		weather.Click_On_MoreDetails();
		Thread.sleep(2000);

		cweather.Click_On_RightwardsArrow();
		try {
			WebElement frame1 = driver
					.findElement(By.id("google_ads_iframe_/6581/web/in/interstitial/weather/current_0"));
			driver.switchTo().frame(frame1);

			driver.findElement(By.xpath("//div[@id='dismiss-button']/div")).click();
			driver.switchTo().defaultContent();
		} catch (Exception e) {
			e.printStackTrace();
		}
		dweather.sample();
		Thread.sleep(2000);
		// dweather.sample1();

	}
}
